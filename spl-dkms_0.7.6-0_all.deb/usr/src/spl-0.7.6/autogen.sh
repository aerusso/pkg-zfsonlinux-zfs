#!/bin/sh

autoreconf -fiv
rm -Rf autom4te.cache
